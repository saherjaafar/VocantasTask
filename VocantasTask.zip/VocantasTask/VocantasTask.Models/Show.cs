﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace VocantasTask.Models
{
    [Table("show")]
    public class Show
    {
        [JsonPropertyName("id")]
        public long id { get; set; }

        [JsonPropertyName("name")]
        public string name { get; set; }

        [JsonPropertyName("genders")]
        public string genres { get; set; }

        [JsonPropertyName("premiered")]
        public DateTime? premiered { get; set; }

        [JsonPropertyName("rating")]
        public double? rating { get; set; }

        [JsonPropertyName("summary")]
        public string summary { get; set; }
    }

}
