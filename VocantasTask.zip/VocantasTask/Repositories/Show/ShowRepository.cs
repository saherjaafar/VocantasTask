﻿using AppDBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VocantasTask.Models;

namespace Repositories.Show
{
    public class ShowRepository : IShowRepository
    {
        protected readonly Lazy<AppDbContext> _defaultContext;

        protected AppDbContext _context => _defaultContext.Value;

        public ShowRepository(Lazy<AppDbContext> context)
        {
            _defaultContext = context;
        }

        public VocantasTask.Models.Show Add(VocantasTask.Models.Show entity)
        {
            _context.Show.Add(entity);
            _context.SaveChanges();
            return entity;
        }

        public VocantasTask.Models.Show GetById(long id)
        {
           return _context.Show.Where(x => x.id == id).FirstOrDefault();
        }
    }
}
