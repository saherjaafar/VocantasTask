﻿using VocantasTask.Models;
using Repositories.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Repositories.Show
{
    public interface IShowRepository : IBaseRepository<VocantasTask.Models.Show>
    {
    }
}
