﻿using Microsoft.Extensions.DependencyInjection;
using Repositories.Show;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public static class IServiceCollectionExtension
    {
        public static IServiceCollection AddServiceRepositories(this IServiceCollection services)
        {
            services.AddTransient<IShowRepository, ShowRepository>();

            return services;
        }

    }
}
