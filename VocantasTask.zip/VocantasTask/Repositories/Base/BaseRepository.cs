﻿using AppDBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Base
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        protected readonly Lazy<AppDbContext> _defaultContext;

        protected AppDbContext _context => _defaultContext.Value;

        public BaseRepository(Lazy<AppDbContext> context)
        {
            _defaultContext = context;
        }

        public List<T> GetAll(Expression<Func<T, bool>> predicate, Func<IQueryable<T>, IQueryable<T>> orderByFunc)
        {
            predicate ??= (x) => true;

            var query = _context.Set<T>().AsQueryable().Where(predicate);

            if (orderByFunc is not null) query = orderByFunc(query);

            return query.ToList();
        }

        public T GetById(long id)
        {
            return _context.Set<T>().Find(id);

        }

        public T Add(T entity)
        {
            _context.Set<T>().Add(entity);
            _context.SaveChanges();
            return entity;
        }
    }
}
