﻿using DomainModels.Exceptions;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Services.ApiExceptionFilter
{
    public class ApiExceptionFilter : ExceptionFilterAttribute
    {
        //private static readonly ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static string UnhandledErrors = SystemMessages.UnhandledErrors;


        public ApiExceptionFilter()
        {
        }

        public override void OnException(ExceptionContext context)
        {
            ApiError apiError = new ApiError();


            if (context.Exception is BusinessRuleException)
            {
                // handle explicit 'known' API errors

                BusinessRuleException ex = context.Exception as BusinessRuleException;

                context.Exception = null;

                apiError.Message = ex.Message;

                context.HttpContext.Response.StatusCode = Convert.ToInt32(ApiResponseCode.UnprocessableEntity);

            }
            else if (context.Exception is NoContentException)
            {
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.NoContent;
            }
            else if (context.Exception is UnauthorizedAccessException)
            {
                Exception ex = context.Exception.GetBaseException();

                context.Exception = null;

                apiError.Message = "Unauthorized Access";

                context.HttpContext.Response.StatusCode = Convert.ToInt32(ApiResponseCode.Unauthorized);

            }
            else
            {
                // Unhandled errors

                Exception ex = context.Exception.GetBaseException();

                context.Exception = null;

                apiError.Message = UnhandledErrors;

                context.HttpContext.Response.StatusCode = Convert.ToInt32(ApiResponseCode.InternalServerError);

            }

            // always return a JSON result      

           context.Result = new JsonResult(apiError);

            base.OnException(context);
        }


    }
}
