﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Services.Common
{
    public class CommonService : ICommonService
    {

        private readonly Lazy<IHttpClientFactory> _httpClientFactory;
        private static readonly ILog Log4Net = LogManager.GetLogger(typeof(CommonService));

        protected IHttpClientFactory HttpClientFactory => _httpClientFactory.Value;

        public CommonService(Lazy<IHttpClientFactory> httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<HttpResponseMessage> ApiPostCall(string routeUrl, string content, Dictionary<string, object> RequestHeader)
        {
            HttpClientHandler handler = new HttpClientHandler
            {
                AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate,
                ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            };
            using (var client = HttpClientFactory.CreateClient())// new HttpClient(handler))
            {
                client.Timeout = new TimeSpan(0, 0, 15, 0, 0);
                //var byteArray = Encoding.ASCII.GetBytes(ApiUsername + ":" + ApiPassword);
                //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                var httpConent = new StringContent(content, Encoding.UTF8, "application/json");
                if (RequestHeader != null)
                {
                    foreach (KeyValuePair<string, object> entry in RequestHeader)
                    {
                        client.DefaultRequestHeaders.Add(entry.Key, entry.Value.ToString());
                    }
                }
                HttpResponseMessage responseMessage = null;
                try
                {
                    responseMessage = await client.PostAsync(routeUrl, httpConent);
                }
                catch (Exception ex)
                {
                    if (responseMessage == null)
                    {
                        responseMessage = new HttpResponseMessage();
                    }
                    responseMessage.StatusCode = HttpStatusCode.InternalServerError;
                    responseMessage.ReasonPhrase = string.Format("RestHttpClient.SendRequest failed: {0}", ex);
                }

                return responseMessage;
            }
        }

        
    }
}
