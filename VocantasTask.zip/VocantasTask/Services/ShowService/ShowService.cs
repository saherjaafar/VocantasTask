﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using log4net;
using Services.Common;
using Newtonsoft.Json;
using VocantasTask.Models;
using DomainModels;
using Services.CacheManage;
using Services.enums;
using DomainModels.Exceptions;
using Repositories.Show;
using System.Reflection.PortableExecutable;

namespace Services.Show
{
    public class ShowService : IShowService
    {
        #region Private
        private readonly Lazy<IHttpClientFactory> _httpClientFactory;
        private readonly CacheManager _cacheManager;
        private readonly Lazy<IShowRepository> _showRepository;
        #endregion

        #region Protected
        protected IHttpClientFactory HttpClientFactory => _httpClientFactory.Value;
        protected IShowRepository ShowRepository => _showRepository.Value;
        #endregion


        public ShowService(Lazy<IHttpClientFactory> httpClientFactory, CacheManager cacheManager, Lazy<IShowRepository> showRepository)
        {
            _httpClientFactory = httpClientFactory;
            _cacheManager = cacheManager;
            _showRepository = showRepository;
        }

        public List<ShowModel> GetShows()
        {
            List<ShowModel> shows = new List<ShowModel>();

            //I have integrated caching to introduce and demonstrate this concept.
            if (CheckCache())
                return _cacheManager.Get<List<ShowModel>>(CacheKeysEnum.shows.ToString());

            using (var client = HttpClientFactory.CreateClient())
            {
                client.Timeout = new TimeSpan(0, 0, 15, 0, 0);
                string sUri = "https://api.tvmaze.com/search/shows?q=Star";

                var response = client.GetAsync(sUri);
                if (response.Result.StatusCode == HttpStatusCode.OK)
                {
                    var responseContent = response.Result.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(responseContent))
                    {
                        shows = JsonConvert.DeserializeObject<List<ShowModel>>(responseContent);
                        _cacheManager.Set<List<ShowModel>>(CacheKeysEnum.shows.ToString(), shows);
                    }
                    else
                        throw new NoContentException();
                }
                else
                    throw new BusinessRuleException("Error while fetching shows");
            }

            return shows;
        }

        public VocantasTask.Models.Show Add(ShowModel show)
        {
            if (!show.show.Configuration.IsValidShow())
                throw new BusinessRuleException("Input Validation Error");

            var newShow = ShowRepository.Add(new VocantasTask.Models.Show
            {
                name = show.show.name,
                genres = string.Join(",", show.show.genres),
                premiered = show.show.premiered,
                rating = show.show.rating.average,
                summary = show.show.summary
            });

            return newShow;
        }

        #region Private Functions

        private bool CheckCache()
        {
            return _cacheManager.Exist<List<ShowModel>>(CacheKeysEnum.shows.ToString());
        }

        #endregion
    }
}
