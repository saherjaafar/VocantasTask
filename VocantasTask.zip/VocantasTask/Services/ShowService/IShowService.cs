﻿using DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VocantasTask.Models;

namespace Services.Show
{
    public interface IShowService
    {
        List<ShowModel> GetShows();
        VocantasTask.Models.Show Add(ShowModel show);
    }
}
