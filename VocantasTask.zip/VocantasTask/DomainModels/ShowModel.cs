﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainModels
{
    public class ShowModel
    {
        public Show show { get; set; }


    }

    public class Show
    {
        public long id { get; set; }
        public string url { get; set; }
        public string name { get; set; }
        public List<string> genres { get; set; }
        public DateTime? premiered { get; set; }
        public string summary { get; set; }
        public string JoinedGenders => genres != null ? string.Join(",", genres) : string.Empty;
        public Rating rating { get; set; }
        public Image? image { get; set; }

        private ShowConfiguration configuration;
        [JsonIgnore]
        [NotMapped]
        public ShowConfiguration Configuration
        {
            get
            {
                return configuration = configuration ?? new ShowConfiguration(this); ;
            }
        }
    }

    public class Rating
    {
        public double? average { get; set; }
        public string rating => average != null ? average.ToString() +"/10" : "N/A";
    }

    public class Image
    {
        public string medium { get; set; }
        public string original { get; set; }
    }
}
