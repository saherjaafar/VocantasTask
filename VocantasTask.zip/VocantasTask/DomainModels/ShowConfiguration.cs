﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace DomainModels
{
    public class ShowConfiguration
    {
        #region Private properties

        private Show _show;

        #endregion

        #region Public properties
        public bool IsValid { get; set; } = false;
        #endregion

        public ShowConfiguration(Show show)
        {
            _show = show;
        }

        public bool IsValidShow()
        {
            if(_show.genres.Count > 0 && !string.IsNullOrEmpty(_show.summary)
                && !string.IsNullOrEmpty(_show.name))
                IsValid= true;
            else 
                IsValid= false;

            return IsValid;
        }
    }
}
