﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModels.Exceptions
{
    public enum ApiResponseCode
    {
        Ok = 200,
        NoContent = 204,
        BadRequest = 400,
        Unauthorized = 401,
        UnprocessableEntity = 422,
        InternalServerError = 500
    }
}
