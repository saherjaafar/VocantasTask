﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModels.Exceptions
{
    public class ValidationError
    {
        private string cMessage = "";

        private string cFieldName = "";

        private string cID = "";

        public string Message
        {
            get
            {
                return cMessage;
            }
            set
            {
                cMessage = value;
            }
        }

        public string ControlID
        {
            get
            {
                return cFieldName;
            }
            set
            {
                cFieldName = value;
            }
        }

        public string ID
        {
            get
            {
                return cID;
            }
            set
            {
                cID = value;
            }
        }

        public ValidationError()
        {
        }

        public ValidationError(string message)
        {
            Message = message;
        }

        public ValidationError(string message, string fieldName)
        {
            Message = message;
            ControlID = fieldName;
        }

        public ValidationError(string message, string fieldName, string id)
        {
            Message = message;
            ControlID = fieldName;
            ID = id;
        }
    }
}
