﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModels.Exceptions
{
    public class ValidationErrorCollection : CollectionBase
    {
        //
        // Summary:
        //     Indexer property for the collection that returns and sets an item
        public ValidationError this[int index]
        {
            get
            {
                return (ValidationError)base.List[index];
            }
            set
            {
                base.List[index] = value;
            }
        }

        public void Add(ValidationError Error)
        {
            base.List.Add(Error);
        }

        
        public void Add(string Message, string FieldName = "", string ID = "")
        {
            ValidationError error = new ValidationError
            {
                Message = Message,
                ControlID = FieldName,
                ID = ID
            };
            Add(error);
        }
    }
}
