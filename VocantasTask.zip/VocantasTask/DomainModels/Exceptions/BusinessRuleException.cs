﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModels.Exceptions
{
    public class BusinessRuleException : BaseException
    {
        public BusinessRuleException(string message)
            : base(message)
        {
        }

        public BusinessRuleException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public BusinessRuleException(Exception ex, int statusCode = 500)
            : base(ex.Message)
        {
            base.StatusCode = statusCode;
        }

        public BusinessRuleException(string message, int statusCode = 500, ValidationErrorCollection errors = null, int StatusCode = 0, ValidationErrorCollection Errors = null)
            : base(message, StatusCode, Errors)
        {
            StatusCode = statusCode;
            Errors = errors;
        }
    }
}
