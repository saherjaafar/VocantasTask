﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModels.Exceptions
{
    public static class SystemMessages
    {
        public static string UnhandledErrors = "Unhandled Errors Exception. Please contact your administrator.";

        public static string BusinessExceptionType = "BusinessRuleException";

        public static string UnhandledExceptionType = "UnhandledErrorException";
    }
}
