﻿var modal = document.getElementById("myModal");

var btn = document.getElementById("openModalBtn");

var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function () {
    modal.style.display = "block";
    populateModalData(); // Fetch data and populate modal inputs
}

span.onclick = function () {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Function to fetch data from API and populate modal inputs
function populateModalData() {
    fetch('https://api.tvmaze.com/shows/42')
        .then(response => response.json())
        .then(data => {
            // Populate form inputs with fetched data
            document.getElementById('name').value = data.name;
            document.getElementById('genres').value = data.genres.join(', ');
            document.getElementById('premiered').value = data.premiered;
            document.getElementById('rating').value = data.rating.average || 'N/A'; 
            document.getElementById('summary').value = data.summary;
        })
        .catch(error => console.error('Error fetching data:', error));
}