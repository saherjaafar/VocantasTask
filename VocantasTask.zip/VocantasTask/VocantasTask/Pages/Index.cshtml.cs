﻿using DomainModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Services.Show;
using System.Net.Http;

namespace VocantasTask.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly Lazy<IShowService> _showService;

        public string Name { get; set; }
        public string Genres { get; set; }
        public double? Rating { get; set; }
        public DateTime? Premiered { get; set; }
        public string Summary { get; set; }

        protected IShowService ShowService => _showService.Value;

        public List<ShowModel> shows = new List<ShowModel>();

        public IndexModel(ILogger<IndexModel> logger, Lazy<IShowService> showService)
        {
            _logger = logger;
            _showService = showService;
        }

        public void OnGet()
        {
            shows = ShowService.GetShows();
            shows = shows.Where(x => x.show.image != null).ToList();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            Name = Request.Form["name"];
            Genres = Request.Form["genres"];
            Premiered = Request.Form["Premiered"] == "" ? null : DateTime.Parse(Request.Form["Premiered"]);
            Rating = Request.Form["rating"] == "N/A" ? null : double.Parse(Request.Form["rating"]);
            Summary = Request.Form["summary"];

            var xx = new ShowModel
            {
                show = new Show
                {
                    name = Name,
                    genres = Genres.Split(',').ToList(),
                    summary = Summary,
                    premiered = Premiered,
                    rating = new Rating
                    {
                        average = Rating
                    }
                },
            };

            ShowService.Add(xx);


            return RedirectToPage("/Index");
        }
    }
}