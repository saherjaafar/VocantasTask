﻿using Microsoft.AspNetCore.Mvc;
using Services.Show;

namespace VocantasTask.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/show/v{version:apiVersion}")]
    [ApiController]
    public class ShowController : Controller
    {
        private readonly IShowService _showService;

        public ShowController(IShowService showService)
        {
            _showService= showService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_showService.GetShows());
        }
    }
}
