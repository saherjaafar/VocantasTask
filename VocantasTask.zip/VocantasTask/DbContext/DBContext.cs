﻿

using Microsoft.EntityFrameworkCore;

namespace DbContext
{
    public class DBContext1 : DbContext
    {
        public DBContext1(DbContextOptions<DBContext1> options)
            : base(options)
        {
        }

        // DbSet properties for your entities
        // public DbSet<YourEntity> YourEntities { get; set; }

        // Override if needed: protected override void OnModelCreating(ModelBuilder modelBuilder)
    }
}
